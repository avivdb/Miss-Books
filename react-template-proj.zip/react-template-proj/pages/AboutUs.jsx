export function AboutUs() {
    return (
        <section className="about-us">
            <h1>About Miss Books</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus vitae at unde. Quasi quod non, consequuntur error perferendis est eveniet sunt! Totam odit possimus ducimus id maxime culpa error ipsum.</p>
        </section>
    )
}